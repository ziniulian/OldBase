package lzr.java.util.Inf;

public interface InfCallback {
	void callback (Object obj);
}
